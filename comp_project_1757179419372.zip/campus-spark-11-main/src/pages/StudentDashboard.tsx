import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Calendar, Clock, MapPin, Users, Star, LogOut, User, Mail, Phone, GraduationCap, Building } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

const StudentDashboard = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [registeredEvents, setRegisteredEvents] = useState([
    {
      id: 1,
      title: "Tech Innovation Summit",
      description: "Explore the latest in technology and innovation",
      date: "2024-01-15",
      time: "10:00 AM",
      location: "Main Auditorium",
      capacity: 200,
      registered: 150,
      isRegistered: true,
      category: "Technology"
    }
  ]);

  const availableEvents = [
    {
      id: 2,
      title: "Career Fair 2024",
      description: "Meet top employers and explore career opportunities",
      date: "2024-01-20",
      time: "9:00 AM",
      location: "Student Center",
      capacity: 500,
      registered: 320,
      isRegistered: false,
      category: "Career"
    },
    {
      id: 3,
      title: "Cultural Festival",
      description: "Celebrate diversity through music, dance, and food",
      date: "2024-01-25",
      time: "6:00 PM",
      location: "Campus Grounds",
      capacity: 1000,
      registered: 780,
      isRegistered: false,
      category: "Cultural"
    },
    {
      id: 4,
      title: "Research Symposium",
      description: "Present and discuss cutting-edge research projects",
      date: "2024-02-01",
      time: "2:00 PM",
      location: "Science Building",
      capacity: 150,
      registered: 89,
      isRegistered: false,
      category: "Academic"
    },
    {
      id: 5,
      title: "Sports Day",
      description: "Inter-departmental sports competition",
      date: "2024-02-05",
      time: "8:00 AM",
      location: "Sports Complex",
      capacity: 300,
      registered: 245,
      isRegistered: false,
      category: "Sports"
    }
  ];

  const [selectedEvent, setSelectedEvent] = useState<any>(null);
  const [isRegistrationOpen, setIsRegistrationOpen] = useState(false);
  const [registrationForm, setRegistrationForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    studentId: "",
    department: "",
    year: "",
    emergencyContact: "",
    dietaryRestrictions: "",
    specialRequirements: ""
  });

  const handleRegister = (eventId: number) => {
    const event = availableEvents.find(e => e.id === eventId);
    if (event) {
      setSelectedEvent(event);
      setIsRegistrationOpen(true);
    }
  };

  const handleRegistrationSubmit = () => {
    if (!registrationForm.firstName || !registrationForm.lastName || !registrationForm.email || !registrationForm.phone || !registrationForm.studentId) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return;
    }

    setRegisteredEvents([...registeredEvents, { ...selectedEvent, isRegistered: true }]);
    setIsRegistrationOpen(false);
    setRegistrationForm({
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      studentId: "",
      department: "",
      year: "",
      emergencyContact: "",
      dietaryRestrictions: "",
      specialRequirements: ""
    });
    
    toast({
      title: "Registration Successful!",
      description: `You have successfully registered for ${selectedEvent?.title}`,
    });
  };

  const getCategoryColor = (category: string) => {
    const colors = {
      Technology: "bg-blue-100 text-blue-800",
      Career: "bg-green-100 text-green-800",
      Cultural: "bg-purple-100 text-purple-800",
      Academic: "bg-orange-100 text-orange-800",
      Sports: "bg-red-100 text-red-800"
    };
    return colors[category as keyof typeof colors] || "bg-gray-100 text-gray-800";
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Avatar className="h-10 w-10">
                <AvatarFallback>JS</AvatarFallback>
              </Avatar>
              <div>
                <h1 className="text-xl font-semibold">Welcome, John Smith</h1>
                <p className="text-sm text-muted-foreground">Computer Science Student</p>
              </div>
            </div>
            <Button 
              variant="outline" 
              onClick={() => navigate("/")}
              className="flex items-center space-x-2"
            >
              <LogOut className="h-4 w-4" />
              <span>Logout</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* My Events */}
            <div className="mb-8">
              <h2 className="text-2xl font-bold mb-6 flex items-center">
                <Star className="h-6 w-6 mr-2 text-campus-orange" />
                My Registered Events
              </h2>
              {registeredEvents.length > 0 ? (
                <div className="grid gap-4">
                  {registeredEvents.map((event) => (
                    <Card key={event.id} className="border-l-4 border-l-campus-green">
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div>
                            <CardTitle className="text-lg">{event.title}</CardTitle>
                            <CardDescription className="mt-1">{event.description}</CardDescription>
                          </div>
                          <Badge className={getCategoryColor(event.category)}>
                            {event.category}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid md:grid-cols-3 gap-4 text-sm">
                          <div className="flex items-center text-muted-foreground">
                            <Calendar className="h-4 w-4 mr-2" />
                            {event.date}
                          </div>
                          <div className="flex items-center text-muted-foreground">
                            <Clock className="h-4 w-4 mr-2" />
                            {event.time}
                          </div>
                          <div className="flex items-center text-muted-foreground">
                            <MapPin className="h-4 w-4 mr-2" />
                            {event.location}
                          </div>
                        </div>
                        <div className="mt-4 flex items-center justify-between">
                          <div className="flex items-center text-sm text-muted-foreground">
                            <Users className="h-4 w-4 mr-2" />
                            {event.registered}/{event.capacity} registered
                          </div>
                          <Badge variant="secondary" className="bg-green-100 text-green-800">
                            Registered ✓
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card className="text-center py-8">
                  <CardContent>
                    <Calendar className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-muted-foreground">No events registered yet. Browse available events below!</p>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Available Events */}
            <div>
              <h2 className="text-2xl font-bold mb-6 flex items-center">
                <Calendar className="h-6 w-6 mr-2 text-campus-blue" />
                Available Events
              </h2>
              <div className="grid gap-4">
                {availableEvents.map((event) => (
                  <Card key={event.id} className="hover:shadow-md transition-all duration-200">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-lg">{event.title}</CardTitle>
                          <CardDescription className="mt-1">{event.description}</CardDescription>
                        </div>
                        <Badge className={getCategoryColor(event.category)}>
                          {event.category}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid md:grid-cols-3 gap-4 text-sm mb-4">
                        <div className="flex items-center text-muted-foreground">
                          <Calendar className="h-4 w-4 mr-2" />
                          {event.date}
                        </div>
                        <div className="flex items-center text-muted-foreground">
                          <Clock className="h-4 w-4 mr-2" />
                          {event.time}
                        </div>
                        <div className="flex items-center text-muted-foreground">
                          <MapPin className="h-4 w-4 mr-2" />
                          {event.location}
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center text-sm text-muted-foreground">
                          <Users className="h-4 w-4 mr-2" />
                          {event.registered}/{event.capacity} registered
                        </div>
                        <Button 
                          onClick={() => handleRegister(event.id)}
                          disabled={event.registered >= event.capacity}
                          variant={event.registered >= event.capacity ? "secondary" : "default"}
                          className="bg-gradient-to-r from-campus-blue to-campus-green hover:from-campus-blue/90 hover:to-campus-green/90 text-white shadow-lg hover:shadow-xl transition-all duration-300"
                        >
                          {event.registered >= event.capacity ? "Full" : "Register Now"}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Events Registered</span>
                  <span className="font-semibold text-campus-green">{registeredEvents.length}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Events Available</span>
                  <span className="font-semibold text-campus-blue">{availableEvents.length}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Upcoming Events</span>
                  <span className="font-semibold text-campus-orange">3</span>
                </div>
              </CardContent>
            </Card>

            {/* Categories */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Event Categories</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {["Technology", "Career", "Cultural", "Academic", "Sports"].map((category) => (
                    <div key={category} className="flex items-center justify-between">
                      <Badge variant="outline" className={getCategoryColor(category)}>
                        {category}
                      </Badge>
                      <span className="text-sm text-muted-foreground">
                        {availableEvents.filter(e => e.category === category).length}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Registration Dialog */}
      <Dialog open={isRegistrationOpen} onOpenChange={setIsRegistrationOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-campus-blue to-campus-green bg-clip-text text-transparent">
              Event Registration
            </DialogTitle>
            <p className="text-muted-foreground">
              Complete your registration for: <span className="font-semibold text-campus-blue">{selectedEvent?.title}</span>
            </p>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            {/* Personal Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold flex items-center">
                <User className="h-5 w-5 mr-2 text-campus-blue" />
                Personal Information
              </h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName" className="text-sm font-medium">First Name *</Label>
                  <Input
                    id="firstName"
                    value={registrationForm.firstName}
                    onChange={(e) => setRegistrationForm({...registrationForm, firstName: e.target.value})}
                    className="border-2 focus:border-campus-blue transition-colors"
                    placeholder="Enter your first name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName" className="text-sm font-medium">Last Name *</Label>
                  <Input
                    id="lastName"
                    value={registrationForm.lastName}
                    onChange={(e) => setRegistrationForm({...registrationForm, lastName: e.target.value})}
                    className="border-2 focus:border-campus-blue transition-colors"
                    placeholder="Enter your last name"
                  />
                </div>
              </div>
            </div>

            {/* Contact Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold flex items-center">
                <Mail className="h-5 w-5 mr-2 text-campus-green" />
                Contact Information
              </h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-sm font-medium">Email Address *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={registrationForm.email}
                    onChange={(e) => setRegistrationForm({...registrationForm, email: e.target.value})}
                    className="border-2 focus:border-campus-green transition-colors"
                    placeholder="your.email@university.edu"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-sm font-medium">Phone Number *</Label>
                  <Input
                    id="phone"
                    value={registrationForm.phone}
                    onChange={(e) => setRegistrationForm({...registrationForm, phone: e.target.value})}
                    className="border-2 focus:border-campus-green transition-colors"
                    placeholder="+1 (555) 123-4567"
                  />
                </div>
              </div>
            </div>

            {/* Academic Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold flex items-center">
                <GraduationCap className="h-5 w-5 mr-2 text-campus-orange" />
                Academic Information
              </h3>
              <div className="grid md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="studentId" className="text-sm font-medium">Student ID *</Label>
                  <Input
                    id="studentId"
                    value={registrationForm.studentId}
                    onChange={(e) => setRegistrationForm({...registrationForm, studentId: e.target.value})}
                    className="border-2 focus:border-campus-orange transition-colors"
                    placeholder="STU123456"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="department" className="text-sm font-medium">Department</Label>
                  <Select
                    value={registrationForm.department}
                    onValueChange={(value) => setRegistrationForm({...registrationForm, department: value})}
                  >
                    <SelectTrigger className="border-2 focus:border-campus-orange">
                      <SelectValue placeholder="Select department" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="computer-science">Computer Science</SelectItem>
                      <SelectItem value="engineering">Engineering</SelectItem>
                      <SelectItem value="business">Business</SelectItem>
                      <SelectItem value="arts">Arts & Humanities</SelectItem>
                      <SelectItem value="sciences">Sciences</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="year" className="text-sm font-medium">Academic Year</Label>
                  <Select
                    value={registrationForm.year}
                    onValueChange={(value) => setRegistrationForm({...registrationForm, year: value})}
                  >
                    <SelectTrigger className="border-2 focus:border-campus-orange">
                      <SelectValue placeholder="Select year" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="freshman">Freshman</SelectItem>
                      <SelectItem value="sophomore">Sophomore</SelectItem>
                      <SelectItem value="junior">Junior</SelectItem>
                      <SelectItem value="senior">Senior</SelectItem>
                      <SelectItem value="graduate">Graduate</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Additional Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold flex items-center">
                <Building className="h-5 w-5 mr-2 text-purple-600" />
                Additional Information
              </h3>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="emergencyContact" className="text-sm font-medium">Emergency Contact</Label>
                  <Input
                    id="emergencyContact"
                    value={registrationForm.emergencyContact}
                    onChange={(e) => setRegistrationForm({...registrationForm, emergencyContact: e.target.value})}
                    className="border-2 focus:border-purple-600 transition-colors"
                    placeholder="Emergency contact phone number"
                  />
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="dietaryRestrictions" className="text-sm font-medium">Dietary Restrictions</Label>
                    <Textarea
                      id="dietaryRestrictions"
                      value={registrationForm.dietaryRestrictions}
                      onChange={(e) => setRegistrationForm({...registrationForm, dietaryRestrictions: e.target.value})}
                      className="border-2 focus:border-purple-600 transition-colors resize-none"
                      placeholder="Any dietary restrictions or allergies..."
                      rows={3}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="specialRequirements" className="text-sm font-medium">Special Requirements</Label>
                    <Textarea
                      id="specialRequirements"
                      value={registrationForm.specialRequirements}
                      onChange={(e) => setRegistrationForm({...registrationForm, specialRequirements: e.target.value})}
                      className="border-2 focus:border-purple-600 transition-colors resize-none"
                      placeholder="Accessibility needs, accommodations..."
                      rows={3}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Event Details Summary */}
            <div className="bg-gradient-to-r from-campus-blue/10 to-campus-green/10 p-4 rounded-lg border border-campus-blue/20">
              <h4 className="font-semibold text-campus-blue mb-2">Event Summary</h4>
              <div className="grid md:grid-cols-3 gap-4 text-sm">
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 mr-2 text-campus-blue" />
                  {selectedEvent?.date}
                </div>
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-2 text-campus-green" />
                  {selectedEvent?.time}
                </div>
                <div className="flex items-center">
                  <MapPin className="h-4 w-4 mr-2 text-campus-orange" />
                  {selectedEvent?.location}
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 pt-4">
              <Button
                onClick={handleRegistrationSubmit}
                className="flex-1 bg-gradient-to-r from-campus-blue to-campus-green hover:from-campus-blue/90 hover:to-campus-green/90 text-white shadow-lg hover:shadow-xl transition-all duration-300"
                size="lg"
              >
                Complete Registration
              </Button>
              <Button
                onClick={() => setIsRegistrationOpen(false)}
                variant="outline"
                className="flex-1 border-2 border-campus-blue/20 hover:border-campus-blue hover:bg-campus-blue/5"
                size="lg"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default StudentDashboard;