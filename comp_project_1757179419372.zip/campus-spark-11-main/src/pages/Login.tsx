import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { GraduationCap, Shield, Calendar, Users } from "lucide-react";
import { useNavigate } from "react-router-dom";
import campusHero from "@/assets/campus-hero.jpg";

const Login = () => {
  const [userType, setUserType] = useState<"student" | "admin">("student");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = () => {
    // For now, just navigate to dashboard based on user type
    if (userType === "admin") {
      navigate("/admin-dashboard");
    } else {
      navigate("/student-dashboard");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-campus-blue via-campus-purple to-campus-blue-light">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src={campusHero} 
            alt="Campus" 
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-campus-blue/90 to-campus-purple/90" />
        </div>
        
        <div className="relative z-10 container mx-auto px-4 py-16">
          <div className="text-center text-white mb-16">
            <div className="flex items-center justify-center mb-6">
              <GraduationCap className="h-16 w-16 mr-4" />
              <h1 className="text-5xl font-bold">CampusEvents</h1>
            </div>
            <p className="text-xl opacity-90 max-w-2xl mx-auto">
              Your comprehensive platform for managing campus events, registrations, and student engagement
            </p>
          </div>

          {/* Features */}
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <div className="text-center text-white">
              <Calendar className="h-12 w-12 mx-auto mb-4 text-campus-orange" />
              <h3 className="text-xl font-semibold mb-2">Event Management</h3>
              <p className="opacity-80">Create and manage campus events with ease</p>
            </div>
            <div className="text-center text-white">
              <Users className="h-12 w-12 mx-auto mb-4 text-campus-green" />
              <h3 className="text-xl font-semibold mb-2">Student Registration</h3>
              <p className="opacity-80">Simple registration and attendance tracking</p>
            </div>
            <div className="text-center text-white">
              <Shield className="h-12 w-12 mx-auto mb-4 text-campus-orange" />
              <h3 className="text-xl font-semibold mb-2">Admin Controls</h3>
              <p className="opacity-80">Comprehensive administrative tools</p>
            </div>
          </div>

          {/* Login Cards */}
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Student Login */}
            <Card className={`transition-all duration-300 ${userType === "student" ? "ring-2 ring-campus-green shadow-[0_0_30px_rgba(34,197,94,0.3)]" : ""}`}>
              <CardHeader className="text-center">
                <div className="flex justify-center mb-4">
                  <GraduationCap className="h-12 w-12 text-campus-green" />
                </div>
                <CardTitle className="text-2xl">Student Portal</CardTitle>
                <CardDescription>Access events and register for activities</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="student-email">Email</Label>
                  <Input
                    id="student-email"
                    type="email"
                    placeholder="student@university.edu"
                    value={userType === "student" ? email : ""}
                    onChange={(e) => {
                      if (userType === "student") setEmail(e.target.value);
                    }}
                    onFocus={() => setUserType("student")}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="student-password">Password</Label>
                  <Input
                    id="student-password"
                    type="password"
                    placeholder="Enter your password"
                    value={userType === "student" ? password : ""}
                    onChange={(e) => {
                      if (userType === "student") setPassword(e.target.value);
                    }}
                    onFocus={() => setUserType("student")}
                  />
                </div>
                <Button 
                  variant={userType === "student" ? "default" : "secondary"}
                  className="w-full"
                  onClick={() => {
                    setUserType("student");
                    handleLogin();
                  }}
                >
                  Login as Student
                </Button>
              </CardContent>
            </Card>

            {/* Admin Login */}
            <Card className={`transition-all duration-300 ${userType === "admin" ? "ring-2 ring-campus-orange shadow-[0_0_30px_rgba(249,115,22,0.3)]" : ""}`}>
              <CardHeader className="text-center">
                <div className="flex justify-center mb-4">
                  <Shield className="h-12 w-12 text-campus-orange" />
                </div>
                <CardTitle className="text-2xl">Admin Portal</CardTitle>
                <CardDescription>Manage events and student activities</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="admin-email">Email</Label>
                  <Input
                    id="admin-email"
                    type="email"
                    placeholder="admin@university.edu"
                    value={userType === "admin" ? email : ""}
                    onChange={(e) => {
                      if (userType === "admin") setEmail(e.target.value);
                    }}
                    onFocus={() => setUserType("admin")}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="admin-password">Password</Label>
                  <Input
                    id="admin-password"
                    type="password"
                    placeholder="Enter your password"
                    value={userType === "admin" ? password : ""}
                    onChange={(e) => {
                      if (userType === "admin") setPassword(e.target.value);
                    }}
                    onFocus={() => setUserType("admin")}
                  />
                </div>
                <Button 
                  variant={userType === "admin" ? "default" : "secondary"}
                  className="w-full"
                  onClick={() => {
                    setUserType("admin");
                    handleLogin();
                  }}
                >
                  Login as Admin
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;